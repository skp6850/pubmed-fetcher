# pubmed_fetcher/exceptions.py
class PubMedFetchError(Exception):
    pass